using KompletteringNiklas;

namespace MStestNiklas
{
    [TestClass]
    public class UnitTest1
    {
        [TestClass]
        public class ProgramTests
        {
            [TestMethod]
            public void FiltreradeFrukterMedA()
            {
                // Arrange
                filterMetod filter = new filterMetod();
                string[] allaFrukter = { "apple", "banan", "apelsin", "kiwi", "ananas" };
                List<string> f�rv�ntadResultat = new List<string> { "apple", "apelsin", "ananas" };

                // Act
                List<string> resultat = filter.FiltreradeFrukterMedA(allaFrukter);

                // Assert
                CollectionAssert.AreEqual(f�rv�ntadResultat, resultat);
            }

            [TestMethod]
            public void FiltreradeNamnEgenBokstav()
            {
                // Arrange
                egenBosktav egenBokstav = new egenBosktav();
                string[] allaNamn = { "Anna", "bodil", "Calle", "David", "Eva" };
                egenBokstav.X = "B";
                List<string> f�rv�ntadResultat = new List<string> { "bodil" };

                // Act
                List<string> resultat = egenBokstav.FiltreradeNamnEgenBokstav(allaNamn);

                // Assert
                CollectionAssert.AreEqual(f�rv�ntadResultat, resultat);
            }
        }

    }
}